
export function Button({ children, ...props }) {
  return <button className="px-4 py-2 bg-blue-600 text-white rounded" {...props}>{children}</button>;
}
export function Card({ children, ...props }) {
  return <div className="bg-white rounded shadow p-4" {...props}>{children}</div>;
}
export function CardContent({ children }) {
  return <div>{children}</div>;
}
export function Input({ ...props }) {
  return <input className="border p-2 w-full rounded" {...props} />;
}
export function Textarea({ ...props }) {
  return <textarea className="border p-2 w-full rounded" {...props} />;
}
