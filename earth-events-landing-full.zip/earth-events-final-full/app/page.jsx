
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function EarthEVentsLanding() {
  const [lang, setLang] = useState("en");
  const [formData, setFormData] = useState({
    email: "",
    search: "",
    problems: "",
    cities: "",
    description: ""
  });
  const [confirmation, setConfirmation] = useState(false);

  const t = {
    en: {
      title: "🌍 EarthEVents",
      subtitle: "Live authentic cultural experiences wherever you travel. Discover real, sustainable events recommended by local people.",
      tryApp: "Want to try our app?",
      emailPrompt: "Leave your email and be among the first to discover the world with EarthEVents.",
      emailPlaceholder: "Your email",
      joinBtn: "I want to join!",
      survey: "🧪 Quick Survey",
      q1: "1. Are you interested in discovering cultural events when you travel?",
      q2: "2. How do you usually look for them?",
      q3: "3. What problems do you face when looking for authentic events?",
      q4: "4. Would you like to have an app like EarthEVents?",
      q5: "5. In which cities would you like to use it first?",
      q6: "6. Optional: Tell us more about your ideal cultural travel experience.",
      selectYesAlways: "Yes, always",
      selectSometimes: "Sometimes",
      selectNoInterest: "Not interested",
      selectYes: "Yes",
      selectNo: "No",
      selectNotSure: "Not sure",
      placeholderSearch: "Google, social media, asking locals, etc.",
      placeholderProblems: "Write it here...",
      placeholderCities: "E.g. Barcelona, Mexico City, Lisbon...",
      placeholderDescription: "What kind of experiences are you looking for?",
      submit: "Submit Answers",
      previewTitle: "👀 App Preview: EarthEVents",
      previewNote: "*These screens are simulations showing what the EarthEVents experience will look like.",
      confirmationMsg: "✅ Thank you! Your answers have been submitted."
    },
    es: {
      title: "🌍 EarthEVents",
      subtitle: "Vive experiencias culturales auténticas donde sea que viajes. Descubre eventos reales y sostenibles recomendados por personas locales.",
      tryApp: "¿Te gustaría probar nuestra app?",
      emailPrompt: "Déjanos tu email y sé de los primeros en descubrir el mundo con EarthEVents.",
      emailPlaceholder: "Tu email",
      joinBtn: "¡Quiero unirme!",
      survey: "🧪 Encuesta rápida",
      q1: "1. ¿Te interesa descubrir eventos culturales cuando viajas?",
      q2: "2. ¿Cómo sueles buscarlos?",
      q3: "3. ¿Qué problemas encuentras al buscar eventos auténticos?",
      q4: "4. ¿Te gustaría tener una app como EarthEVents?",
      q5: "5. ¿En qué ciudades te gustaría usarla primero?",
      q6: "6. Opcional: Cuéntanos más sobre tu experiencia cultural ideal al viajar.",
      selectYesAlways: "Sí, siempre",
      selectSometimes: "A veces",
      selectNoInterest: "No me interesa",
      selectYes: "Sí",
      selectNo: "No",
      selectNotSure: "No lo sé",
      placeholderSearch: "Google, redes sociales, preguntar, etc.",
      placeholderProblems: "Escríbelo aquí...",
      placeholderCities: "Ej. Barcelona, Ciudad de México, Lisboa...",
      placeholderDescription: "¿Qué tipo de experiencias estás buscando?",
      submit: "Enviar respuestas",
      previewTitle: "👀 Vista previa de la app EarthEVents",
      previewNote: "*Estas pantallas son simuladas para mostrar cómo será la experiencia real de EarthEVents.",
      confirmationMsg: "✅ ¡Gracias! Tus respuestas han sido enviadas."
    }
  }; // 🔧 Se ha cerrado correctamente el objeto 't'

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    await fetch("https://api.sheetmonkey.io/form/smueqtowZDhEJBbvY83h3Y", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    });
    setConfirmation(true);
    setFormData({ email: "", search: "", problems: "", cities: "", description: "" });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-blue-100 py-10 px-4 flex flex-col items-center text-center">
      <div className="mb-6">
        <img
          src="/logo-earthevents.png"
          alt="EarthEVents Logo"
          width={200}
          height={200}
        />
        <div className="mt-2 space-x-2">
          <Button variant={lang === "es" ? "default" : "outline"} onClick={() => setLang("es")}>ES</Button>
          <Button variant={lang === "en" ? "default" : "outline"} onClick={() => setLang("en")}>EN</Button>
        </div>
      </div>
      <h1 className="text-4xl font-bold mb-4">{t[lang].title}</h1>
      <p className="text-xl mb-6 max-w-xl">{t[lang].subtitle}</p>
    </div>
  );
}
